#Muestra un simple mensaje, Hola Mundo, para ilustrar la estructrura típica de un programa.

# La funcion se llamará main, su estructura se define por la palabra reservada def y el nombre de la funcion

def main():
  print("Hola mundo, ahora en Python")