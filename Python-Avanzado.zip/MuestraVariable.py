# Función donde se declara una variable, y la muestra.

def main():
  txt="Hola mundo, con variable"
  print(txt)
  